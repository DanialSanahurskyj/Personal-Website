# Danial Sanahurskyj: personal site

Plain HTML on GitHub Pages. No build step.

- `index.html`: home page (bio, contact, Research, Bedford Capital Management)
- `data/index.html`: War–Peace Index page (reads `data/war_peace_index.csv` when it loads)
- `scripts/update_index.py`: nightly GDELT update
- `.github/workflows/update-index.yml`: runs the update every night at 04:17 UTC and commits the new CSV
- `assets/site.css`: shared styles
- `papers/`: put paper PDFs here and link them from `index.html`

To finish: add `photo.jpg` and swap the placeholder div for `<img src="photo.jpg" alt="Danial Sanahurskyj">`,
add `cv.pdf` at the root, and replace every gray TODO tag.

## Publish
1. Create a new public GitHub repo and upload everything in this folder, including the hidden `.github` folder and `.nojekyll`.
2. Settings → Pages → Deploy from branch `main`, folder `/ (root)`.
3. Settings → Actions → General → Workflow permissions → "Read and write permissions" (lets the nightly job commit).
4. Actions tab → "Update War-Peace Index" → Run workflow, once, to backfill from August to today.
5. Custom domain: Settings → Pages → enter the domain. At your registrar, add A records for the apex to
   185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153 and a CNAME `www` → `<username>.github.io`.
   Tick "Enforce HTTPS" once it's offered.
